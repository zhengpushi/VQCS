
type __ = Obj.t
let __ = let rec f _ = Obj.repr f in Obj.repr f

type 'a option =
| Some of 'a
| None

type ('a, 'b) prod =
| Pair of 'a * 'b

(** val snd : ('a1, 'a2) prod -> 'a2 **)

let snd = function
| Pair (_, y) -> y

type comparison =
| Eq
| Lt
| Gt

(** val compOpp : comparison -> comparison **)

let compOpp = function
| Eq -> Eq
| Lt -> Gt
| Gt -> Lt

type 'a sig0 = 'a
  (* singleton inductive, whose constructor was exist *)

type 'a sumor =
| Inleft of 'a
| Inright

module Coq__1 = struct
 (** val add : int -> int -> int **)
 let rec add n m =
   (fun fO fS n -> if n=0 then fO () else fS (n-1))
     (fun _ -> m)
     (fun p -> Int.succ (add p m))
     n
end
include Coq__1

type positive =
| XI of positive
| XO of positive
| XH

type z =
| Z0
| Zpos of positive
| Zneg of positive

module Nat =
 struct
  (** val add : int -> int -> int **)

  let rec add n m =
    (fun fO fS n -> if n=0 then fO () else fS (n-1))
      (fun _ -> m)
      (fun p -> Int.succ (add p m))
      n

  (** val mul : int -> int -> int **)

  let rec mul n m =
    (fun fO fS n -> if n=0 then fO () else fS (n-1))
      (fun _ -> 0)
      (fun p -> add m (mul p m))
      n

  (** val pow : int -> int -> int **)

  let rec pow n m =
    (fun fO fS n -> if n=0 then fO () else fS (n-1))
      (fun _ -> Int.succ 0)
      (fun m0 -> mul n (pow n m0))
      m
 end

module Pos =
 struct
  type mask =
  | IsNul
  | IsPos of positive
  | IsNeg
 end

module Coq_Pos =
 struct
  (** val succ : positive -> positive **)

  let rec succ = function
  | XI p -> XO (succ p)
  | XO p -> XI p
  | XH -> XO XH

  (** val add : positive -> positive -> positive **)

  let rec add x y =
    match x with
    | XI p ->
      (match y with
       | XI q0 -> XO (add_carry p q0)
       | XO q0 -> XI (add p q0)
       | XH -> XO (succ p))
    | XO p ->
      (match y with
       | XI q0 -> XI (add p q0)
       | XO q0 -> XO (add p q0)
       | XH -> XI p)
    | XH -> (match y with
             | XI q0 -> XO (succ q0)
             | XO q0 -> XI q0
             | XH -> XO XH)

  (** val add_carry : positive -> positive -> positive **)

  and add_carry x y =
    match x with
    | XI p ->
      (match y with
       | XI q0 -> XI (add_carry p q0)
       | XO q0 -> XO (add_carry p q0)
       | XH -> XI (succ p))
    | XO p ->
      (match y with
       | XI q0 -> XO (add_carry p q0)
       | XO q0 -> XI (add p q0)
       | XH -> XO (succ p))
    | XH ->
      (match y with
       | XI q0 -> XI (succ q0)
       | XO q0 -> XO (succ q0)
       | XH -> XI XH)

  (** val pred_double : positive -> positive **)

  let rec pred_double = function
  | XI p -> XI (XO p)
  | XO p -> XI (pred_double p)
  | XH -> XH

  type mask = Pos.mask =
  | IsNul
  | IsPos of positive
  | IsNeg

  (** val succ_double_mask : mask -> mask **)

  let succ_double_mask = function
  | IsNul -> IsPos XH
  | IsPos p -> IsPos (XI p)
  | IsNeg -> IsNeg

  (** val double_mask : mask -> mask **)

  let double_mask = function
  | IsPos p -> IsPos (XO p)
  | x0 -> x0

  (** val double_pred_mask : positive -> mask **)

  let double_pred_mask = function
  | XI p -> IsPos (XO (XO p))
  | XO p -> IsPos (XO (pred_double p))
  | XH -> IsNul

  (** val sub_mask : positive -> positive -> mask **)

  let rec sub_mask x y =
    match x with
    | XI p ->
      (match y with
       | XI q0 -> double_mask (sub_mask p q0)
       | XO q0 -> succ_double_mask (sub_mask p q0)
       | XH -> IsPos (XO p))
    | XO p ->
      (match y with
       | XI q0 -> succ_double_mask (sub_mask_carry p q0)
       | XO q0 -> double_mask (sub_mask p q0)
       | XH -> IsPos (pred_double p))
    | XH -> (match y with
             | XH -> IsNul
             | _ -> IsNeg)

  (** val sub_mask_carry : positive -> positive -> mask **)

  and sub_mask_carry x y =
    match x with
    | XI p ->
      (match y with
       | XI q0 -> succ_double_mask (sub_mask_carry p q0)
       | XO q0 -> double_mask (sub_mask p q0)
       | XH -> IsPos (pred_double p))
    | XO p ->
      (match y with
       | XI q0 -> double_mask (sub_mask_carry p q0)
       | XO q0 -> succ_double_mask (sub_mask_carry p q0)
       | XH -> double_pred_mask p)
    | XH -> IsNeg

  (** val sub : positive -> positive -> positive **)

  let sub x y =
    match sub_mask x y with
    | IsPos z0 -> z0
    | _ -> XH

  (** val mul : positive -> positive -> positive **)

  let rec mul x y =
    match x with
    | XI p -> add y (XO (mul p y))
    | XO p -> XO (mul p y)
    | XH -> y

  (** val size_nat : positive -> int **)

  let rec size_nat = function
  | XI p0 -> Int.succ (size_nat p0)
  | XO p0 -> Int.succ (size_nat p0)
  | XH -> Int.succ 0

  (** val compare_cont : comparison -> positive -> positive -> comparison **)

  let rec compare_cont r x y =
    match x with
    | XI p ->
      (match y with
       | XI q0 -> compare_cont r p q0
       | XO q0 -> compare_cont Gt p q0
       | XH -> Gt)
    | XO p ->
      (match y with
       | XI q0 -> compare_cont Lt p q0
       | XO q0 -> compare_cont r p q0
       | XH -> Gt)
    | XH -> (match y with
             | XH -> r
             | _ -> Lt)

  (** val compare : positive -> positive -> comparison **)

  let compare =
    compare_cont Eq

  (** val eqb : positive -> positive -> bool **)

  let rec eqb p q0 =
    match p with
    | XI p0 -> (match q0 with
                | XI q1 -> eqb p0 q1
                | _ -> false)
    | XO p0 -> (match q0 with
                | XO q1 -> eqb p0 q1
                | _ -> false)
    | XH -> (match q0 with
             | XH -> true
             | _ -> false)

  (** val ggcdn :
      int -> positive -> positive -> (positive, (positive, positive) prod)
      prod **)

  let rec ggcdn n a b =
    (fun fO fS n -> if n=0 then fO () else fS (n-1))
      (fun _ -> Pair (XH, (Pair (a, b))))
      (fun n0 ->
      match a with
      | XI a' ->
        (match b with
         | XI b' ->
           (match compare a' b' with
            | Eq -> Pair (a, (Pair (XH, XH)))
            | Lt ->
              let Pair (g, p) = ggcdn n0 (sub b' a') a in
              let Pair (ba, aa) = p in Pair (g, (Pair (aa, (add aa (XO ba)))))
            | Gt ->
              let Pair (g, p) = ggcdn n0 (sub a' b') b in
              let Pair (ab, bb) = p in Pair (g, (Pair ((add bb (XO ab)), bb))))
         | XO b0 ->
           let Pair (g, p) = ggcdn n0 a b0 in
           let Pair (aa, bb) = p in Pair (g, (Pair (aa, (XO bb))))
         | XH -> Pair (XH, (Pair (a, XH))))
      | XO a0 ->
        (match b with
         | XI _ ->
           let Pair (g, p) = ggcdn n0 a0 b in
           let Pair (aa, bb) = p in Pair (g, (Pair ((XO aa), bb)))
         | XO b0 -> let Pair (g, p) = ggcdn n0 a0 b0 in Pair ((XO g), p)
         | XH -> Pair (XH, (Pair (a, XH))))
      | XH -> Pair (XH, (Pair (XH, b))))
      n

  (** val ggcd :
      positive -> positive -> (positive, (positive, positive) prod) prod **)

  let ggcd a b =
    ggcdn (Coq__1.add (size_nat a) (size_nat b)) a b

  (** val iter_op : ('a1 -> 'a1 -> 'a1) -> positive -> 'a1 -> 'a1 **)

  let rec iter_op op p a =
    match p with
    | XI p0 -> op a (iter_op op p0 (op a a))
    | XO p0 -> iter_op op p0 (op a a)
    | XH -> a

  (** val to_nat : positive -> int **)

  let to_nat x =
    iter_op Coq__1.add x (Int.succ 0)

  (** val of_nat : int -> positive **)

  let rec of_nat n =
    (fun fO fS n -> if n=0 then fO () else fS (n-1))
      (fun _ -> XH)
      (fun x ->
      (fun fO fS n -> if n=0 then fO () else fS (n-1))
        (fun _ -> XH)
        (fun _ -> succ (of_nat x))
        x)
      n

  (** val of_succ_nat : int -> positive **)

  let rec of_succ_nat n =
    (fun fO fS n -> if n=0 then fO () else fS (n-1))
      (fun _ -> XH)
      (fun x -> succ (of_succ_nat x))
      n
 end

module Z =
 struct
  (** val double : z -> z **)

  let double = function
  | Z0 -> Z0
  | Zpos p -> Zpos (XO p)
  | Zneg p -> Zneg (XO p)

  (** val succ_double : z -> z **)

  let succ_double = function
  | Z0 -> Zpos XH
  | Zpos p -> Zpos (XI p)
  | Zneg p -> Zneg (Coq_Pos.pred_double p)

  (** val pred_double : z -> z **)

  let pred_double = function
  | Z0 -> Zneg XH
  | Zpos p -> Zpos (Coq_Pos.pred_double p)
  | Zneg p -> Zneg (XI p)

  (** val pos_sub : positive -> positive -> z **)

  let rec pos_sub x y =
    match x with
    | XI p ->
      (match y with
       | XI q0 -> double (pos_sub p q0)
       | XO q0 -> succ_double (pos_sub p q0)
       | XH -> Zpos (XO p))
    | XO p ->
      (match y with
       | XI q0 -> pred_double (pos_sub p q0)
       | XO q0 -> double (pos_sub p q0)
       | XH -> Zpos (Coq_Pos.pred_double p))
    | XH ->
      (match y with
       | XI q0 -> Zneg (XO q0)
       | XO q0 -> Zneg (Coq_Pos.pred_double q0)
       | XH -> Z0)

  (** val add : z -> z -> z **)

  let add x y =
    match x with
    | Z0 -> y
    | Zpos x' ->
      (match y with
       | Z0 -> x
       | Zpos y' -> Zpos (Coq_Pos.add x' y')
       | Zneg y' -> pos_sub x' y')
    | Zneg x' ->
      (match y with
       | Z0 -> x
       | Zpos y' -> pos_sub y' x'
       | Zneg y' -> Zneg (Coq_Pos.add x' y'))

  (** val opp : z -> z **)

  let opp = function
  | Z0 -> Z0
  | Zpos x0 -> Zneg x0
  | Zneg x0 -> Zpos x0

  (** val sub : z -> z -> z **)

  let sub m n =
    add m (opp n)

  (** val mul : z -> z -> z **)

  let mul x y =
    match x with
    | Z0 -> Z0
    | Zpos x' ->
      (match y with
       | Z0 -> Z0
       | Zpos y' -> Zpos (Coq_Pos.mul x' y')
       | Zneg y' -> Zneg (Coq_Pos.mul x' y'))
    | Zneg x' ->
      (match y with
       | Z0 -> Z0
       | Zpos y' -> Zneg (Coq_Pos.mul x' y')
       | Zneg y' -> Zpos (Coq_Pos.mul x' y'))

  (** val compare : z -> z -> comparison **)

  let compare x y =
    match x with
    | Z0 -> (match y with
             | Z0 -> Eq
             | Zpos _ -> Lt
             | Zneg _ -> Gt)
    | Zpos x' -> (match y with
                  | Zpos y' -> Coq_Pos.compare x' y'
                  | _ -> Gt)
    | Zneg x' ->
      (match y with
       | Zneg y' -> compOpp (Coq_Pos.compare x' y')
       | _ -> Lt)

  (** val sgn : z -> z **)

  let sgn = function
  | Z0 -> Z0
  | Zpos _ -> Zpos XH
  | Zneg _ -> Zneg XH

  (** val eqb : z -> z -> bool **)

  let eqb x y =
    match x with
    | Z0 -> (match y with
             | Z0 -> true
             | _ -> false)
    | Zpos p -> (match y with
                 | Zpos q0 -> Coq_Pos.eqb p q0
                 | _ -> false)
    | Zneg p -> (match y with
                 | Zneg q0 -> Coq_Pos.eqb p q0
                 | _ -> false)

  (** val max : z -> z -> z **)

  let max n m =
    match compare n m with
    | Lt -> m
    | _ -> n

  (** val min : z -> z -> z **)

  let min n m =
    match compare n m with
    | Gt -> m
    | _ -> n

  (** val abs : z -> z **)

  let abs = function
  | Zneg p -> Zpos p
  | x -> x

  (** val to_nat : z -> int **)

  let to_nat = function
  | Zpos p -> Coq_Pos.to_nat p
  | _ -> 0

  (** val of_nat : int -> z **)

  let of_nat n =
    (fun fO fS n -> if n=0 then fO () else fS (n-1))
      (fun _ -> Z0)
      (fun n0 -> Zpos (Coq_Pos.of_succ_nat n0))
      n

  (** val to_pos : z -> positive **)

  let to_pos = function
  | Zpos p -> p
  | _ -> XH

  (** val ggcd : z -> z -> (z, (z, z) prod) prod **)

  let ggcd a b =
    match a with
    | Z0 -> Pair ((abs b), (Pair (Z0, (sgn b))))
    | Zpos a0 ->
      (match b with
       | Z0 -> Pair ((abs a), (Pair ((sgn a), Z0)))
       | Zpos b0 ->
         let Pair (g, p) = Coq_Pos.ggcd a0 b0 in
         let Pair (aa, bb) = p in
         Pair ((Zpos g), (Pair ((Zpos aa), (Zpos bb))))
       | Zneg b0 ->
         let Pair (g, p) = Coq_Pos.ggcd a0 b0 in
         let Pair (aa, bb) = p in
         Pair ((Zpos g), (Pair ((Zpos aa), (Zneg bb)))))
    | Zneg a0 ->
      (match b with
       | Z0 -> Pair ((abs a), (Pair ((sgn a), Z0)))
       | Zpos b0 ->
         let Pair (g, p) = Coq_Pos.ggcd a0 b0 in
         let Pair (aa, bb) = p in
         Pair ((Zpos g), (Pair ((Zneg aa), (Zpos bb))))
       | Zneg b0 ->
         let Pair (g, p) = Coq_Pos.ggcd a0 b0 in
         let Pair (aa, bb) = p in
         Pair ((Zpos g), (Pair ((Zneg aa), (Zneg bb)))))
 end

(** val zcompare_rect :
    z -> z -> (__ -> 'a1) -> (__ -> 'a1) -> (__ -> 'a1) -> 'a1 **)

let zcompare_rect n m h1 h2 h3 =
  let c = Z.compare n m in
  (match c with
   | Eq -> h1 __
   | Lt -> h2 __
   | Gt -> h3 __)

(** val zcompare_rec :
    z -> z -> (__ -> 'a1) -> (__ -> 'a1) -> (__ -> 'a1) -> 'a1 **)

let zcompare_rec =
  zcompare_rect

(** val z_lt_dec : z -> z -> bool **)

let z_lt_dec x y =
  match Z.compare x y with
  | Lt -> true
  | _ -> false

(** val z_lt_ge_dec : z -> z -> bool **)

let z_lt_ge_dec =
  z_lt_dec

(** val z_le_lt_eq_dec : z -> z -> bool **)

let z_le_lt_eq_dec x y =
  zcompare_rec x y (fun _ -> false) (fun _ -> true) (fun _ -> assert false
    (* absurd case *))

(** val z_dec : z -> z -> bool sumor **)

let z_dec x y =
  if z_lt_ge_dec x y
  then Inleft true
  else if z_le_lt_eq_dec y x then Inleft false else Inright

type q = { qnum : z; qden : positive }

(** val qmult : q -> q -> q **)

let qmult x y =
  { qnum = (Z.mul x.qnum y.qnum); qden = (Coq_Pos.mul x.qden y.qden) }

(** val qinv : q -> q **)

let qinv x =
  match x.qnum with
  | Z0 -> { qnum = Z0; qden = XH }
  | Zpos p -> { qnum = (Zpos x.qden); qden = p }
  | Zneg p -> { qnum = (Zneg x.qden); qden = p }

(** val qdiv : q -> q -> q **)

let qdiv x y =
  qmult x (qinv y)

(** val qred : q -> q **)

let qred q0 =
  let { qnum = q1; qden = q2 } = q0 in
  let Pair (r1, r2) = snd (Z.ggcd q1 (Zpos q2)) in
  { qnum = r1; qden = (Z.to_pos r2) }

type cReal = { seq : (z -> q); scale : z }

type dReal = (q -> bool)

module type RbaseSymbolsSig =
 sig
  type coq_R

  val coq_Rabst : cReal -> coq_R

  val coq_Rrepr : coq_R -> cReal

  val coq_R0 : coq_R

  val coq_R1 : coq_R

  val coq_Rplus : coq_R -> coq_R -> coq_R

  val coq_Rmult : coq_R -> coq_R -> coq_R

  val coq_Ropp : coq_R -> coq_R
 end

module RbaseSymbolsImpl =
 struct
  type coq_R = float

  (** val coq_Rabst : cReal -> dReal **)

  let coq_Rabst = __

  (** val coq_Rrepr : dReal -> cReal **)

  let coq_Rrepr = __

  (** val coq_Rquot1 : __ **)

  let coq_Rquot1 =
    __

  (** val coq_Rquot2 : __ **)

  let coq_Rquot2 =
    __

  (** val coq_R0 : coq_R **)

  let coq_R0 = 0.0

  (** val coq_R1 : coq_R **)

  let coq_R1 = 1.0

  (** val coq_Rplus : coq_R -> coq_R -> coq_R **)

  let coq_Rplus = (+.)

  (** val coq_Rmult : coq_R -> coq_R -> coq_R **)

  let coq_Rmult = ( *. )

  (** val coq_Ropp : coq_R -> coq_R **)

  let coq_Ropp = fun a -> (0.0 -. a)

  type coq_Rlt = __

  (** val coq_R0_def : __ **)

  let coq_R0_def =
    __

  (** val coq_R1_def : __ **)

  let coq_R1_def =
    __

  (** val coq_Rplus_def : __ **)

  let coq_Rplus_def =
    __

  (** val coq_Rmult_def : __ **)

  let coq_Rmult_def =
    __

  (** val coq_Ropp_def : __ **)

  let coq_Ropp_def =
    __

  (** val coq_Rlt_def : __ **)

  let coq_Rlt_def =
    __
 end

(** val iPR_2 : positive -> RbaseSymbolsImpl.coq_R **)

let rec iPR_2 = function
| XI p0 ->
  RbaseSymbolsImpl.coq_Rmult
    (RbaseSymbolsImpl.coq_Rplus RbaseSymbolsImpl.coq_R1
      RbaseSymbolsImpl.coq_R1)
    (RbaseSymbolsImpl.coq_Rplus RbaseSymbolsImpl.coq_R1 (iPR_2 p0))
| XO p0 ->
  RbaseSymbolsImpl.coq_Rmult
    (RbaseSymbolsImpl.coq_Rplus RbaseSymbolsImpl.coq_R1
      RbaseSymbolsImpl.coq_R1) (iPR_2 p0)
| XH ->
  RbaseSymbolsImpl.coq_Rplus RbaseSymbolsImpl.coq_R1 RbaseSymbolsImpl.coq_R1

(** val iPR : positive -> RbaseSymbolsImpl.coq_R **)

let iPR = function
| XI p0 -> RbaseSymbolsImpl.coq_Rplus RbaseSymbolsImpl.coq_R1 (iPR_2 p0)
| XO p0 -> iPR_2 p0
| XH -> RbaseSymbolsImpl.coq_R1

(** val iZR : z -> RbaseSymbolsImpl.coq_R **)

let iZR = function
| Z0 -> RbaseSymbolsImpl.coq_R0
| Zpos n -> iPR n
| Zneg n -> RbaseSymbolsImpl.coq_Ropp (iPR n)

module type RinvSig =
 sig
  val coq_Rinv : RbaseSymbolsImpl.coq_R -> RbaseSymbolsImpl.coq_R
 end

module RinvImpl =
 struct
  (** val coq_Rinv : RbaseSymbolsImpl.coq_R -> RbaseSymbolsImpl.coq_R **)

  let coq_Rinv = fun a -> (1.0 /. a)

  (** val coq_Rinv_def : __ **)

  let coq_Rinv_def =
    __
 end

(** val q2R : q -> RbaseSymbolsImpl.coq_R **)

let q2R x =
  RbaseSymbolsImpl.coq_Rmult (iZR x.qnum)
    (RinvImpl.coq_Rinv (iZR (Zpos x.qden)))

type basicUnit =
| BUTime
| BULength
| BUMass
| BUElectricCurrent
| BUThermodynamicTemperature
| BUAmountOfSubstance
| BULuminousIntensity
| BURadian

(** val basicUnit_beq : basicUnit -> basicUnit -> bool **)

let rec basicUnit_beq x y =
  match x with
  | BUTime -> (match y with
               | BUTime -> true
               | _ -> false)
  | BULength -> (match y with
                 | BULength -> true
                 | _ -> false)
  | BUMass -> (match y with
               | BUMass -> true
               | _ -> false)
  | BUElectricCurrent -> (match y with
                          | BUElectricCurrent -> true
                          | _ -> false)
  | BUThermodynamicTemperature ->
    (match y with
     | BUThermodynamicTemperature -> true
     | _ -> false)
  | BUAmountOfSubstance ->
    (match y with
     | BUAmountOfSubstance -> true
     | _ -> false)
  | BULuminousIntensity ->
    (match y with
     | BULuminousIntensity -> true
     | _ -> false)
  | BURadian -> (match y with
                 | BURadian -> true
                 | _ -> false)

(** val basicUnit_eq_dec : basicUnit -> basicUnit -> bool **)

let basicUnit_eq_dec x y =
  let b = basicUnit_beq x y in if b then true else false

type unit0 =
| Unone of q
| Ubu of basicUnit
| Uinv of unit0
| Umul of unit0 * unit0

(** val upown : unit0 -> int -> unit0 **)

let rec upown u n =
  (fun fO fS n -> if n=0 then fO () else fS (n-1))
    (fun _ -> Unone { qnum = (Zpos XH); qden = XH })
    (fun n' ->
    (fun fO fS n -> if n=0 then fO () else fS (n-1))
      (fun _ -> u)
      (fun _ -> Umul (u, (upown u n')))
      n')
    n

(** val upow : unit0 -> z -> unit0 **)

let upow u = function
| Z0 -> Unone { qnum = (Zpos XH); qden = XH }
| Zpos p -> upown u (Coq_Pos.to_nat p)
| Zneg p -> Uinv (upown u (Coq_Pos.to_nat p))

(** val ugetcoef : unit0 -> q **)

let rec ugetcoef = function
| Unone c -> c
| Ubu _ -> { qnum = (Zpos XH); qden = XH }
| Uinv u1 -> qinv (ugetcoef u1)
| Umul (u1, u2) -> qmult (ugetcoef u1) (ugetcoef u2)

(** val ugetdim : unit0 -> basicUnit -> z **)

let rec ugetdim u b =
  match u with
  | Unone _ -> Z0
  | Ubu bu -> if basicUnit_eq_dec bu b then Zpos XH else Z0
  | Uinv u1 -> Z.opp (ugetdim u1 b)
  | Umul (u1, u2) -> Z.add (ugetdim u1 b) (ugetdim u2 b)

(** val ugenpown : basicUnit -> int -> unit0 **)

let rec ugenpown b n =
  (fun fO fS n -> if n=0 then fO () else fS (n-1))
    (fun _ -> Unone { qnum = (Zpos XH); qden = XH })
    (fun n' ->
    (fun fO fS n -> if n=0 then fO () else fS (n-1))
      (fun _ -> Ubu b)
      (fun _ -> Umul ((ugenpown b n'), (Ubu b)))
      n')
    n

(** val ugenpow : basicUnit -> z -> unit0 **)

let ugenpow b dim =
  match z_dec Z0 dim with
  | Inleft dec2 ->
    if dec2
    then ugenpown b (Z.to_nat dim)
    else Uinv (ugenpown b (Z.to_nat (Z.opp dim)))
  | Inright -> Unone { qnum = (Zpos XH); qden = XH }

(** val ucons : unit0 -> basicUnit -> z -> unit0 **)

let ucons base b dim =
  if Z.eqb dim Z0 then base else Umul (base, (ugenpow b dim))

type dims = { d1 : z; d2 : z; d3 : z; d4 : z; d5 : z; d6 : z; d7 : z; d8 : z }

(** val deqb : dims -> dims -> bool **)

let deqb d9 d10 =
  if if if if if if if Z.eqb d9.d1 d10.d1 then Z.eqb d9.d2 d10.d2 else false
                 then Z.eqb d9.d3 d10.d3
                 else false
              then Z.eqb d9.d4 d10.d4
              else false
           then Z.eqb d9.d5 d10.d5
           else false
        then Z.eqb d9.d6 d10.d6
        else false
     then Z.eqb d9.d7 d10.d7
     else false
  then Z.eqb d9.d8 d10.d8
  else false

(** val dplus : dims -> dims -> dims **)

let dplus d9 d10 =
  { d1 = (Z.add d9.d1 d10.d1); d2 = (Z.add d9.d2 d10.d2); d3 =
    (Z.add d9.d3 d10.d3); d4 = (Z.add d9.d4 d10.d4); d5 =
    (Z.add d9.d5 d10.d5); d6 = (Z.add d9.d6 d10.d6); d7 =
    (Z.add d9.d7 d10.d7); d8 = (Z.add d9.d8 d10.d8) }

(** val dopp : dims -> dims **)

let dopp d9 =
  { d1 = (Z.opp d9.d1); d2 = (Z.opp d9.d2); d3 = (Z.opp d9.d3); d4 =
    (Z.opp d9.d4); d5 = (Z.opp d9.d5); d6 = (Z.opp d9.d6); d7 =
    (Z.opp d9.d7); d8 = (Z.opp d9.d8) }

type nunit = { ncoef : q; ndims : dims }

(** val nmult : nunit -> nunit -> nunit **)

let nmult n1 n2 =
  { ncoef = (qmult n1.ncoef n2.ncoef); ndims = (dplus n1.ndims n2.ndims) }

(** val ninv : nunit -> nunit **)

let ninv n1 =
  { ncoef = (qinv n1.ncoef); ndims = (dopp n1.ndims) }

(** val u2n : unit0 -> nunit **)

let u2n u =
  { ncoef = (ugetcoef u); ndims = { d1 = (ugetdim u BUTime); d2 =
    (ugetdim u BULength); d3 = (ugetdim u BUMass); d4 =
    (ugetdim u BUElectricCurrent); d5 =
    (ugetdim u BUThermodynamicTemperature); d6 =
    (ugetdim u BUAmountOfSubstance); d7 = (ugetdim u BULuminousIntensity);
    d8 = (ugetdim u BURadian) } }

(** val n2u : nunit -> unit0 **)

let n2u n =
  let { ncoef = coef; ndims = ndims0 } = n in
  let { d1 = ds; d2 = dm; d3 = dkg; d4 = dA; d5 = dK; d6 = dmol; d7 = dcd;
    d8 = drad } = ndims0
  in
  let u = Unone (qred coef) in
  let u0 = ucons u BUTime ds in
  let u1 = ucons u0 BULength dm in
  let u2 = ucons u1 BUMass dkg in
  let u3 = ucons u2 BUElectricCurrent dA in
  let u4 = ucons u3 BUThermodynamicTemperature dK in
  let u5 = ucons u4 BUAmountOfSubstance dmol in
  let u6 = ucons u5 BULuminousIntensity dcd in ucons u6 BURadian drad

module SI_Basic =
 struct
  (** val second : unit0 **)

  let second =
    Ubu BUTime

  (** val metre : unit0 **)

  let metre =
    Ubu BULength
 end

module SI_Accepted =
 struct
  (** val centimetre : unit0 **)

  let centimetre =
    Umul ((Unone { qnum = (Zpos XH); qden = (XO (XO (XI (XO (XO (XI
      XH)))))) }), SI_Basic.metre)

  (** val minute : unit0 **)

  let minute =
    Umul ((Unone { qnum = (Zpos (XO (XO (XI (XI (XI XH)))))); qden = XH }),
      SI_Basic.second)

  (** val litre : unit0 **)

  let litre =
    Umul ((Uinv
      (upow (Unone { qnum = (Zpos (XO (XI (XO XH)))); qden = XH }) (Zpos (XI
        XH)))), (upow SI_Basic.metre (Zpos (XI XH))))
 end

(** val uconv : unit0 -> unit0 -> (q, unit0) prod option **)

let uconv src ref =
  let { ncoef = c1; ndims = d9 } = u2n src in
  let { ncoef = c2; ndims = d10 } = u2n ref in
  if deqb d9 d10 then Some (Pair ((qdiv c1 c2), ref)) else None

type quantity =
| QUmake of RbaseSymbolsImpl.coq_R * nunit
| QUinvalid

(** val genQU : RbaseSymbolsImpl.coq_R -> unit0 -> quantity **)

let genQU val0 u =
  QUmake (val0, (u2n u))

(** val qUvalueERR : RbaseSymbolsImpl.coq_R **)

let qUvalueERR = infinity

(** val qUvalue : quantity -> RbaseSymbolsImpl.coq_R **)

let qUvalue = function
| QUmake (v, _) -> v
| QUinvalid -> qUvalueERR

(** val qUdimERR : dims **)

let qUdimERR = { d1 = Z0; d2 = Z0; d3 = Z0; d4 = Z0; d5 = Z0; d6 = Z0; d7 = Z0; d8 = Z0 }

(** val qUdim : quantity -> dims **)

let qUdim = function
| QUmake (_, n) -> n.ndims
| QUinvalid -> qUdimERR

(** val qUconv : quantity -> unit0 -> quantity **)

let qUconv q0 ref =
  match q0 with
  | QUmake (v, n) ->
    (match uconv (n2u n) ref with
     | Some p ->
       let Pair (k, u) = p in genQU (RbaseSymbolsImpl.coq_Rmult (q2R k) v) u
     | None -> QUinvalid)
  | QUinvalid -> QUinvalid

(** val qUplus : quantity -> quantity -> quantity **)

let qUplus q1 q2 =
  match q1 with
  | QUmake (v1, n1) ->
    (match q2 with
     | QUmake (_, _) ->
       (match qUconv q2 (n2u n1) with
        | QUmake (v2', _) -> QUmake ((RbaseSymbolsImpl.coq_Rplus v1 v2'), n1)
        | QUinvalid -> QUinvalid)
     | QUinvalid -> QUinvalid)
  | QUinvalid -> QUinvalid

(** val qUmult : quantity -> quantity -> quantity **)

let qUmult q1 q2 =
  match q1 with
  | QUmake (v1, n1) ->
    (match q2 with
     | QUmake (v2, n2) ->
       QUmake ((RbaseSymbolsImpl.coq_Rmult v1 v2), (nmult n1 n2))
     | QUinvalid -> QUinvalid)
  | QUinvalid -> QUinvalid

(** val qUinv : quantity -> quantity **)

let qUinv = function
| QUmake (v, n) -> QUmake ((RinvImpl.coq_Rinv v), (ninv n))
| QUinvalid -> QUinvalid

(** val qUdiv : quantity -> quantity -> quantity **)

let qUdiv q1 q2 =
  qUmult q1 (qUinv q2)

(** val fill_time : quantity **)

let fill_time =
  let f1 =
    genQU
      (q2R { qnum = (Zpos (XI (XI (XI (XI (XO (XI (XI (XO XH))))))))); qden =
        (XO (XI (XO XH))) }) (Umul
      ((upow SI_Accepted.centimetre (Zpos (XI XH))), (Uinv SI_Basic.second)))
  in
  let f2 =
    genQU
      (q2R { qnum = (Zpos (XI (XO (XI (XO XH))))); qden = (XO (XI (XO XH))) })
      (Umul (SI_Accepted.litre, (Uinv SI_Accepted.minute)))
  in
  let v =
    genQU (iZR (Zpos (XO (XO (XI (XI (XO (XI (XO (XO XH))))))))))
      (upow SI_Accepted.centimetre (Zpos (XI XH)))
  in
  qUconv (qUdiv v (qUplus f1 f2)) SI_Basic.second

(** val fill_time_val : RbaseSymbolsImpl.coq_R **)

let fill_time_val =
  qUvalue fill_time
